# Başarısız denemeler korunmuştur

PREP01 raw blob/checkout byte mismatch; test0. PREP02 checkout-index mevcutCRLF byte'larını korudu; test0. On dosyada normalize-content eşliği kanıtlandı; izole dosyalar exact raw Git blob'larıyla eşlendi. PREP03 index-stat clean-status duruşu; test0. Command-local autocrlf=false index yenilemesi sonrası tree299b76cc1dfd1095a3ce454afb38a3ca30bc3586 base ile exact eşit; staged/source diff0. PREP04 freeze başarılı.

STATIC01:10check/9success/1failureS07; notify/queue call-start line382/398 beklenirken AST381/397. Başarısız source korunur; yalnız line anchor düzeltildi, dal sırası/başarı amacı/uygulama kaynakları değişmedi. STATIC02 ve FINAL_CLEAN10/10.

FORMAT01 CRLF için whitespace diagnostic; frozen byte'lar korunarak command-local cr-at-eol ile checkPASS. COMMIT01 sandbox author identity eksik, commit oluşmadı; repository'nin önceki Codex identity'si command-local kullanıldı, global config değişmedi. DOC01 artifact-generator template parse hatası, script yazılmadı; güvenli quoting ile düzeltildi. Bunlar strategy failure/production olayı değil.

Failed_Attempt_Records.json ve Failed_Attempts_Evidence.zip kanıtları korur. Parent integrationv1run1/errors2/notrun11/PASSfalse değişmedi.92NOT_RUN testi PASS yapılmadı.
