
import ast,hashlib,json,pathlib,subprocess,sys,zipfile
W=pathlib.Path(__file__).parent;B=W.parent/'v2-witness-redesign-branch';R=B/'research/v2_source_read_witness_redesign'
G=r'C:\Users\BURAK\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\git\cmd\git.exe'
def git(*a):return subprocess.check_output([G,'-c','safe.directory='+B.as_posix(),'-c','core.autocrlf=false','-C',str(B),*a])
def sha(b):return hashlib.sha256(b).hexdigest()
plan=json.loads((R/'Pretest_Freeze_Manifest.json').read_text(encoding='utf-8'))
for x in plan['files']:assert sha((R/x['file']).read_bytes())==x['sha256']
inventory=json.loads((R/'Source_Inventory.json').read_text(encoding='utf-8'))
for x in inventory['files']:
    data=(B/x['path']).read_bytes()
    assert sha(data)==x['sha256'],x['path']
    if x['path'].startswith(('binance_momentum_bot/','tests/')):
        assert data==git('show','29cc15ea261c0a148cd57cee46b986946b4c492f:'+x['path'])
for p in R.glob('*.json'):json.loads(p.read_text(encoding='utf-8'))
for p in R.glob('*.py'):ast.parse(p.read_bytes(),filename=str(p))
with zipfile.ZipFile(R/'Differential_Test_Evidence.zip') as z:
    assert z.testzip() is None
    first=json.loads(z.read('attempt01_complete/Microprototype_Test_Results.json'))
    final=json.loads(z.read('attempt02_diagnostic/Microprototype_Test_Results.json'))
    assert (first['passed'],first['failed'],final['passed'],final['failed'])==(7,25,32,0)
bc=json.loads((R/'Bytecode_Comparison.json').read_text(encoding='utf-8'))
counts={}
for name,ops in bc['original'].items():
    filt=lambda o:[(v['opname'],v['argrepr']) for v in o if v['opname']=='LOAD_GLOBAL' and v['argrepr'] in ['EARLY_NOTIFY_MAX_BUY30','FAST_EARLY_V2_SCORE','IGNITION_V2_MIN_SCORE'] or v['opname']=='LOAD_ATTR' and v['argrepr']=='min_score']
    orig=filt(ops);cand=filt(bc['candidate'][name]);assert orig==cand,(name,orig,cand)
    counts[name]=orig
assert git('diff','--name-only')==b''
parent=git('rev-parse','HEAD').decode().strip();assert parent=='6be46a2d7a8c63430d35ed748b7dd0067e5a7d71'
proof=dict(source_files_verified=len(inventory['files']),frozen_files_verified=len(plan['files']),
 json_syntax_valid=True,python_syntax_valid=True,evidence_zip_crc_valid=True,static_target_load_sequence_equal=counts,
 parent_T001_T092_executed=0,application_existing_tests_workflow_diff=0,decision='D_NOT_LOCKED',
 note='Artifact integrity checks only, not additional adversarial strategy test cases')
(W/'precommit_validation.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof,indent=2))
